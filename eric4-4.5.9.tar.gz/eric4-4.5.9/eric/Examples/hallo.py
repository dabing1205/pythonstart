#!/usr/bin/env python

import sys

def main():
    print "Hello World!"
    sys.exit(0)
    
if __name__ == "__main__":
    main()
